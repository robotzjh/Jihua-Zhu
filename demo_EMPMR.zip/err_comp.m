function [errR, errT] = err_comp(grtR, grtT, pM, scannum, s)

errR = 0;
errT = 0;
for i=1:scannum
    p(i).M(1:4,1:3) = [grtR{i};0 0 0];
    p(i).M(1:4,4) = [grtT{i}*s;1];
    p(i).M= inv(p(1).M)* p(i).M;
    errR = errR + norm(pM(i).M(1:3,1:3)-p(i).M(1:3,1:3),'fro');
    errT = errT + norm(pM(i).M(1:3,4)-p(i).M(1:3,4),2);
end
errR = errR/scannum;
errT = errT/scannum;
